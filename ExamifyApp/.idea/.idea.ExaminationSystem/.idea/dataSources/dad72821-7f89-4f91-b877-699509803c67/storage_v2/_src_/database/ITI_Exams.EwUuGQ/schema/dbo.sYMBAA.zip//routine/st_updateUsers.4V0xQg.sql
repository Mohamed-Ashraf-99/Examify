CREATE PROCEDURE st_updateUsers @user_id INT, @user_fname NVARCHAR(20), @user_lname NVARCHAR(20),
                                @user_email NVARCHAR(50), @user_password NVARCHAR(50)
AS
    SET NOCOUNT ON;

BEGIN TRY
    UPDATE Users
    SET user_fname    = @user_fname,
        user_lname    = @user_lname,
        email_address = @user_email,
        password      = @user_password
    WHERE user_id = @user_id
END TRY
BEGIN CATCH
    SELECT ERROR_NUMBER()    AS ErrorNumber,
           ERROR_MESSAGE()   AS ErrorMessage,
           ERROR_PROCEDURE() AS ErrorProcedure,
           ERROR_LINE()      AS ErrorLine
END CATCH
GO

