CREATE PROCEDURE st_storeStudentExamAnswers @ex_id INT,
                                           @st_name VARCHAR(40),
                                           @answer1 INT,
                                           @answer2 INT,
                                           @answer3 INT,
                                           @answer4 INT,
                                           @answer5 INT,
                                           @answer6 INT,
                                           @answer7 INT,
                                           @answer8 INT,
                                           @answer9 INT,
                                           @answer10 INT
AS
BEGIN
    SET NOCOUNT ON;

    -- Check if the student exists
    IF EXISTS (SELECT user_fname + ' ' + user_lname
               FROM Users
               WHERE CONCAT_WS(' ', user_fname, user_lname) = @st_name)
        BEGIN
            BEGIN TRY
                BEGIN TRANSACTION;

                DECLARE @questions TABLE
                                   (
                                       question_id INT
                                   )

                INSERT INTO @questions (question_id)
                SELECT qs_id
                FROM Includes
                WHERE ex_id = @ex_id;

                DELETE
                FROM Includes
                WHERE ex_id = @ex_id;

                INSERT INTO Includes (ex_id, qs_id, st_answer)
                SELECT @ex_id,
                       qs_id,
                       ch_id
                FROM Multiple_choices
                WHERE ch_id IN (@answer1, @answer2, @answer3, @answer4, @answer5,
                                @answer6, @answer7, @answer8, @answer9, @answer10)
                  AND qs_id IN (SELECT * FROM @questions);

                COMMIT TRANSACTION;
            END TRY
            BEGIN CATCH

                SELECT ERROR_NUMBER()    AS ErrorNumber,
                       ERROR_MESSAGE()   AS ErrorMessage,
                       ERROR_PROCEDURE() AS ErrorProcedure,
                       ERROR_LINE()      AS ErrorLine;

                ROLLBACK TRANSACTION;
            END CATCH;
        END
END
GO

