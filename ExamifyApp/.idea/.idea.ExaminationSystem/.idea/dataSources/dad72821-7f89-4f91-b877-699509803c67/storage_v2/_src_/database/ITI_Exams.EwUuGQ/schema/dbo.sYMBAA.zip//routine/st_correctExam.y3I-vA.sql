CREATE   PROCEDURE st_correctExam @exam_id INT, @student_name NVARCHAR(50)
AS
    SET NOCOUNT ON;

BEGIN TRY
    BEGIN TRANSACTION
        DECLARE @student_id INT , @final_grade DECIMAL ,@exam_grade DECIMAL
        -- GET STUDENT ID BY USING HIS NAME
        SELECT @student_id = U.user_id
        FROM Users U
        WHERE CONCAT(U.user_fname, ' ', U.user_lname) LIKE @student_name
        --CREATE TABLE VARIABLE TO STORE GRADE
        DECLARE @student_grade TABLE
                               (
                                   st_grade INT
                               )
        --INSERT INTO TABLE GRADE TO CALC THE SUM OF GRADE
        INSERT INTO @student_grade
        SELECT Q.qs_grade
        FROM Question Q
            INNER JOIN Includes I
                ON I.qs_id = Q.qs_id
            INNER JOIN Exam E
                ON E.ex_id = I.ex_id
        WHERE E.ex_id = @exam_id
          AND I.st_answer = Q.model_answer

        --GET TOTAL STUDENT GRADE
        SELECT @final_grade = SUM(st_grade) FROM @student_grade

        --GET GRADE EXAM

        SELECT @exam_grade = SUM(Q.qs_grade)
        FROM Question Q
            INNER JOIN
        Includes INC
                ON
                INC.qs_id = Q.qs_id
        WHERE INC.ex_id = @exam_id

        --UPDATE GRADE IN STUDENT EXAM TABLE

        UPDATE Exam
        SET ex_final_grade = (@final_grade / @exam_grade) * 100
        WHERE ex_id = @exam_id
          AND st_id = @student_id


        --SELECT EXAM TABLE
        SELECT @student_name, * FROM Exam WHERE st_id = @student_id AND ex_id = @exam_id
    COMMIT TRANSACTION
END TRY
BEGIN CATCH
    SELECT ERROR_NUMBER()    AS ErrorNumber,
           ERROR_MESSAGE()   AS ErrorMessage,
           ERROR_PROCEDURE() AS ErrorProcedure,
           ERROR_LINE()      AS ErrorLine
END CATCH
GO

