-- UPDATE STATEMENT
CREATE PROCEDURE st_updateInstructor @instructor_id INT, @instructor_degree NVARCHAR(20), @instructor_salary MONEY
AS
    SET NOCOUNT ON;

BEGIN TRY
    UPDATE dbo.Instructor
    SET ins_degree = @instructor_degree,
        ins_salary = @instructor_salary
    WHERE ins_id = @instructor_id
END TRY
BEGIN CATCH
    SELECT ERROR_NUMBER()    AS ErrorNumber,
           ERROR_MESSAGE()   AS ErrorMessage,
           ERROR_PROCEDURE() AS ErrorProcedure,
           ERROR_LINE()      AS ErrorLine
END CATCH
GO

