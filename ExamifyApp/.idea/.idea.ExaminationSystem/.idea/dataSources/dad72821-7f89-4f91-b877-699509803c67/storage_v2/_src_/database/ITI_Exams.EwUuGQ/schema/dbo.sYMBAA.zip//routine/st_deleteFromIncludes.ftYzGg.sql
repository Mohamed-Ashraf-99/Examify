CREATE PROCEDURE st_deleteFromIncludes @exam_id INT, @question_id INT
AS
    SET NOCOUNT ON;

BEGIN TRY
    DELETE
    FROM Includes
    WHERE ex_id = @exam_id
      AND qs_id = @question_id
END TRY
BEGIN CATCH
    SELECT ERROR_NUMBER()    AS ErrorNumber,
           ERROR_MESSAGE()   AS ErrorMessage,
           ERROR_PROCEDURE() AS ErrorProcedure,
           ERROR_LINE()      AS ErrorLine
END CATCH
GO

