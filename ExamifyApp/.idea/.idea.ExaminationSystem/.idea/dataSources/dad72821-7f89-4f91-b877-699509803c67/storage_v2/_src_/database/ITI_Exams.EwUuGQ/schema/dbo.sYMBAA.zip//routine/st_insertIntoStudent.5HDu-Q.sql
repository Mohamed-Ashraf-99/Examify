CREATE PROCEDURE st_insertIntoStudent @student_id INT, @st_address NVARCHAR(50), @department_id INT,
                                     @student_img nvarchar(100)
AS
    SET NOCOUNT ON;

BEGIN TRY
    INSERT INTO Student (st_id, st_address, dept_id, st_img)
    VALUES (@student_id, @st_address, @department_id, @student_img)
END TRY
BEGIN CATCH
    SELECT ERROR_NUMBER()    AS ErrorNumber,
           ERROR_MESSAGE()   AS ErrorMessage,
           ERROR_PROCEDURE() AS ErrorProcedure,
           ERROR_LINE()      AS ErrorLine
END CATCH
GO

