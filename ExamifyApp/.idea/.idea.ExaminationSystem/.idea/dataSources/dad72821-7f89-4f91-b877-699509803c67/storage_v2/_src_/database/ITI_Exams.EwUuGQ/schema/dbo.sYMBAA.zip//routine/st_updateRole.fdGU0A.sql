CREATE PROCEDURE st_updateRole @role_id INT, @role_name NVARCHAR(20), @role_desc NVARCHAR(50)
AS
    SET NOCOUNT ON;

BEGIN TRY
    UPDATE Role
    SET role_name = @role_name,
        role_desc = @role_desc
    WHERE role_id = @role_id
END TRY
BEGIN CATCH
    SELECT ERROR_NUMBER()    AS ErrorNumber,
           ERROR_MESSAGE()   AS ErrorMessage,
           ERROR_PROCEDURE() AS ErrorProcedure,
           ERROR_LINE()      AS ErrorLine
END CATCH
GO

