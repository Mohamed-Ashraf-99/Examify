CREATE PROCEDURE st_insertIntoMultipleChoices @choice_title NCHAR(10), @question_id INT
AS
    SET NOCOUNT ON;

BEGIN TRY
    INSERT INTO Multiple_choices (ch_title, qs_id)
    VALUES (@choice_title, @question_id)
END TRY
BEGIN CATCH
    SELECT ERROR_NUMBER()    AS ErrorNumber,
           ERROR_MESSAGE()   AS ErrorMessage,
           ERROR_PROCEDURE() AS ErrorProcedure,
           ERROR_LINE()      AS ErrorLine
END CATCH
GO

