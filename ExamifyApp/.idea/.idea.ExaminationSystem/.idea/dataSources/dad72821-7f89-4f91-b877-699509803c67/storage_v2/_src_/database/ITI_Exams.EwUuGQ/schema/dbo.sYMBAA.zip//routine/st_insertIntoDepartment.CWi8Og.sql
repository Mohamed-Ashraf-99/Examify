CREATE PROCEDURE st_insertIntoDepartment @department_name NVARCHAR(50), @department_desc NVARCHAR(50),
                                         @department_location NVARCHAR(30), @department_mgr_id INT,
                                         @manager_hire_date DATE
AS
    SET NOCOUNT ON;

BEGIN TRY
    INSERT INTO Department (dept_name, dept_desc, dept_location, dept_mgr_id, mgr_hire_date)
    VALUES (@department_name, @department_desc, @department_location, @department_mgr_id, @manager_hire_date);
END TRY
BEGIN CATCH
    SELECT ERROR_NUMBER()    AS ErrorNumber,
           ERROR_MESSAGE()   AS ErrorMessage,
           ERROR_PROCEDURE() AS ErrorProcedure,
           ERROR_LINE()      AS ErrorLine
END CATCH
GO

