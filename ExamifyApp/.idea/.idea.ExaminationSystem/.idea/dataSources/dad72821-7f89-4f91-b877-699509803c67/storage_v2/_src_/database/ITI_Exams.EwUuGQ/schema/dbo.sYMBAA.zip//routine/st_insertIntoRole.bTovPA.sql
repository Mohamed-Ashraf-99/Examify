CREATE PROCEDURE st_insertIntoRole @role_name NVARCHAR(20), @role_desc NVARCHAR(50)
AS
    SET NOCOUNT ON;

BEGIN TRY
    INSERT INTO Role (role_name, role_desc)
    VALUES (@role_name, @role_desc)
END TRY
BEGIN CATCH
    SELECT ERROR_NUMBER()    AS ErrorNumber,
           ERROR_MESSAGE()   AS ErrorMessage,
           ERROR_PROCEDURE() AS ErrorProcedure,
           ERROR_LINE()      AS ErrorLine
END CATCH
GO

