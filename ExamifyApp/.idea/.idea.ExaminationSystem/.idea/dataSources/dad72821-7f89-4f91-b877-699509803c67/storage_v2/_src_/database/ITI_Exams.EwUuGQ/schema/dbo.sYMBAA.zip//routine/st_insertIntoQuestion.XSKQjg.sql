CREATE PROCEDURE st_insertIntoQuestion @question_title NVARCHAR(100), @question_type NVARCHAR(20),
                                      @question_difficulty NVARCHAR(20), @question_grade DECIMAL(4, 2),
                                      @m_answer INT, @course_id INT
AS
    SET NOCOUNT ON;

BEGIN TRY
    INSERT INTO Question (qs_title, qs_type, qs_difficulty, qs_grade, model_answer, crs_id)
    VALUES (@question_title, @question_type, @question_difficulty, @question_grade, @m_answer, @course_id)
END TRY
BEGIN CATCH
    SELECT ERROR_NUMBER()    AS ErrorNumber,
           ERROR_MESSAGE()   AS ErrorMessage,
           ERROR_PROCEDURE() AS ErrorProcedure,
           ERROR_LINE()      AS ErrorLine
END CATCH
GO

