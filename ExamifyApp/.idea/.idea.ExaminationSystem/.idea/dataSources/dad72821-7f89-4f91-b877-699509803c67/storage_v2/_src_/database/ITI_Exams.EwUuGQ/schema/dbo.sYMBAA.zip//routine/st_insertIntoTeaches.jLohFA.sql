CREATE PROCEDURE st_insertIntoTeaches @instructor_id INT, @course_id INT
AS
    SET NOCOUNT ON;
    
BEGIN TRY
    INSERT INTO Teaches(ins_id, crs_id)
    VALUES (@instructor_id, @course_id)
END TRY
BEGIN CATCH
    SELECT ERROR_NUMBER()    AS ErrorNumber,
           ERROR_MESSAGE()   AS ErrorMessage,
           ERROR_PROCEDURE() AS ErrorProcedure,
           ERROR_LINE()      AS ErrorLine
END CATCH
GO

