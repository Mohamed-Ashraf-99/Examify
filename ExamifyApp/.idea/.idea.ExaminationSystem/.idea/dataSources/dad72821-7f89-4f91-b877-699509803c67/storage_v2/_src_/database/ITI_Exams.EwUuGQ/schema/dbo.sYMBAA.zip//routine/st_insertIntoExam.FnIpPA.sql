CREATE PROCEDURE st_insertIntoExam @exam_name NVARCHAR(50), @exam_final_grade DECIMAL(5, 2), @student_id INT,
                                  @exam_id INT OUT
AS
    SET NOCOUNT ON;

BEGIN TRY
    INSERT INTO Exam (ex_name, ex_final_grade, st_id)
    VALUES (@exam_name, @exam_final_grade, @student_id);

    SELECT TOP 1 @exam_id = ex_id FROM Exam ORDER BY ex_id DESC;
END TRY
BEGIN CATCH
    SELECT ERROR_NUMBER()    AS ErrorNumber,
           ERROR_MESSAGE()   AS ErrorMessage,
           ERROR_PROCEDURE() AS ErrorProcedure,
           ERROR_LINE()      AS ErrorLine
END CATCH
GO

