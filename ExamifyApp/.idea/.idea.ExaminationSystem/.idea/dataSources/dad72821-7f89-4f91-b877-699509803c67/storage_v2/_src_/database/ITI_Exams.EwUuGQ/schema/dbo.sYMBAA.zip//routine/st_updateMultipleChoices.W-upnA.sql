-- UPDATE STATEMENT
CREATE PROCEDURE st_updateMultipleChoices @choice_id INT, @choice_title NCHAR(10), @question_id INT
AS
    SET NOCOUNT ON;

BEGIN TRY
    UPDATE Multiple_choices
    SET ch_title = @choice_title,
        qs_id    = @question_id
    WHERE ch_id = @choice_id
END TRY
BEGIN CATCH
    SELECT ERROR_NUMBER()    AS ErrorNumber,
           ERROR_MESSAGE()   AS ErrorMessage,
           ERROR_PROCEDURE() AS ErrorProcedure,
           ERROR_LINE()      AS ErrorLine
END CATCH
GO

