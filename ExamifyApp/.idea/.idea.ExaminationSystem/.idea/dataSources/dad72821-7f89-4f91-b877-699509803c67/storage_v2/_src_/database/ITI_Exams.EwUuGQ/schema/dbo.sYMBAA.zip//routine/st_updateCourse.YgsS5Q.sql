CREATE PROCEDURE st_updateCourse @course_id INT, @course_name NVARCHAR(50), @course_duration INT
AS
    SET NOCOUNT ON;

BEGIN TRY
    UPDATE Course
    SET crs_name     = @course_name,
        crs_duration = @course_duration
    WHERE crs_id = @course_id
END TRY
BEGIN CATCH
    SELECT ERROR_NUMBER()    AS ErrorNumber,
           ERROR_MESSAGE()   AS ErrorMessage,
           ERROR_PROCEDURE() AS ErrorProcedure,
           ERROR_LINE()      AS ErrorLine
END CATCH
GO

