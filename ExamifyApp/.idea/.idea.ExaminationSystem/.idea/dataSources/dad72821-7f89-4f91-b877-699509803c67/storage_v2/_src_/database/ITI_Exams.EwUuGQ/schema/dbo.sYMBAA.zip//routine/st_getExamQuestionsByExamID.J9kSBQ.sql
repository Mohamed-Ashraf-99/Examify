CREATE   PROCEDURE st_getExamQuestionsByExamID @exam_id INT
AS
    SET NOCOUNT ON;

BEGIN TRY
    SELECT DENSE_RANK() OVER (ORDER BY q.qs_id) AS "Question#",
           q.qs_title,
           m.ch_title
    FROM Includes i
        INNER JOIN Question q
            ON i.qs_id = q.qs_id
        INNER JOIN Multiple_choices m
            ON q.qs_id = m.qs_id
    WHERE i.ex_id = @exam_id;
END TRY
BEGIN CATCH
    SELECT ERROR_NUMBER()    AS ErrorNumber,
           ERROR_MESSAGE()   AS ErrorMessage,
           ERROR_PROCEDURE() AS ErrorProcedure,
           ERROR_LINE()      AS ErrorLine
END CATCH
GO

