CREATE   PROCEDURE st_showExamWithStudentAnswers @exam_id INT, @student_id INT
AS
    SET NOCOUNT ON;

BEGIN TRY
    DECLARE @student_name NVARCHAR(50);

    SELECT @student_name = CONCAT(user_fname, ' ', user_lname)
    FROM Users
    WHERE user_id = @student_id;

    SELECT DENSE_RANK() OVER (ORDER BY q.qs_id)                              AS "Question#",
           q.qs_title,
           (SELECT ch_title FROM Multiple_choices WHERE ch_id = i.st_answer) AS "Student_Answer",
           @student_name                                                     AS "Student_name"
    FROM Includes i
        INNER JOIN Question q
            ON i.qs_id = q.qs_id
    WHERE i.ex_id = @exam_id;
END TRY
BEGIN CATCH
    SELECT ERROR_NUMBER()    AS ErrorNumber,
           ERROR_MESSAGE()   AS ErrorMessage,
           ERROR_PROCEDURE() AS ErrorProcedure,
           ERROR_LINE()      AS ErrorLine
END CATCH
GO

