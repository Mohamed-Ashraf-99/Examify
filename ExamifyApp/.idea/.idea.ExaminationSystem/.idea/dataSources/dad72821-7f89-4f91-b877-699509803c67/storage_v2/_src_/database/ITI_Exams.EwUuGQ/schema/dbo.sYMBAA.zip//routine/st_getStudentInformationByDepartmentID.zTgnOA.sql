CREATE   PROCEDURE st_getStudentInformationByDepartmentID @dept_num INT
AS
    SET NOCOUNT ON;

BEGIN TRY
    SELECT s.st_id                       AS ID,
           ISNULL(u.user_name, 'NA')     AS Full_Name,
           ISNULL(u.email_address, 'NA') AS Email,
           ISNULL(s.st_address, 'NA')    AS Address
    FROM Users u
        INNER JOIN Student s
            ON s.st_id = u.user_id
    WHERE s.dept_id = @dept_num;

END TRY
BEGIN CATCH

    SELECT ERROR_NUMBER()    AS ErrorNumber,
           ERROR_MESSAGE()   AS ErrorMessage,
           ERROR_PROCEDURE() AS ErrorProcedure,
           ERROR_LINE()      AS ErrorLine;

END CATCH
GO

