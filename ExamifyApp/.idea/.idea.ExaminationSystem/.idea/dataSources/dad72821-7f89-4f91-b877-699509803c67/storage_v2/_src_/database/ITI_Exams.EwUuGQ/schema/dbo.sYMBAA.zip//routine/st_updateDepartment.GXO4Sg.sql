CREATE PROCEDURE st_updateDepartment @department_id INT, @department_name NVARCHAR(50), @department_desc NVARCHAR(50),
                                     @department_location NVARCHAR(30), @department_mgr_id INT,
                                     @manager_hire_date DATE
AS
    SET NOCOUNT ON;

BEGIN TRY
    UPDATE Department
    SET dept_name     = @department_name,
        dept_desc     = @department_desc,
        dept_location = @department_location,
        dept_mgr_id   = @department_mgr_id,
        mgr_hire_date = @manager_hire_date
    WHERE dept_id = @department_id;
END TRY
BEGIN CATCH
    SELECT ERROR_NUMBER()    AS ErrorNumber,
           ERROR_MESSAGE()   AS ErrorMessage,
           ERROR_PROCEDURE() AS ErrorProcedure,
           ERROR_LINE()      AS ErrorLine
END CATCH
GO

