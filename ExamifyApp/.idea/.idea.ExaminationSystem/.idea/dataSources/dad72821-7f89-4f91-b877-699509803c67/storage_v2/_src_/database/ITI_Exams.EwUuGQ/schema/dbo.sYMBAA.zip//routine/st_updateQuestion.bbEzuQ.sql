CREATE PROCEDURE st_updateQuestion @question_id INT, @question_title NVARCHAR(100), @question_type NVARCHAR(20),
                                  @question_difficulty NVARCHAR(20), @question_grade DECIMAL(4, 2), @m_answer INT,
                                  @course_id INT
AS
    SET NOCOUNT ON;

BEGIN TRY
    UPDATE Question
    SET qs_title      = @question_title,
        qs_type       = @question_type,
        qs_difficulty = @question_difficulty,
        qs_grade      = @question_grade,
        model_answer  = @m_answer,
        crs_id        = @course_id
    WHERE qs_id = @question_id

END TRY
BEGIN CATCH
    SELECT ERROR_NUMBER()    AS ErrorNumber,
           ERROR_MESSAGE()   AS ErrorMessage,
           ERROR_PROCEDURE() AS ErrorProcedure,
           ERROR_LINE()      AS ErrorLine
END CATCH
GO

