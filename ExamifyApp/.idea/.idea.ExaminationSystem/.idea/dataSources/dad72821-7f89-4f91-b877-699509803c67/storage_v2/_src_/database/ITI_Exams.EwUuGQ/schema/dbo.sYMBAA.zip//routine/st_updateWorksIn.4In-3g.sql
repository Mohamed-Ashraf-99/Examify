CREATE PROCEDURE st_updateWorksIn @instructor_id INT, @old_department_id INT, @department_id INT
AS
    SET NOCOUNT ON;
    
BEGIN TRY
    UPDATE Works_in
    SET dept_id = @department_id
    WHERE ins_id = @instructor_id
      AND dept_id = @old_department_id

END TRY
BEGIN CATCH
    SELECT ERROR_NUMBER()    AS ErrorNumber,
           ERROR_MESSAGE()   AS ErrorMessage,
           ERROR_PROCEDURE() AS ErrorProcedure,
           ERROR_LINE()      AS ErrorLine
END CATCH
GO

