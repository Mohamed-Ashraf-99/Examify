CREATE PROCEDURE st_insertIntoUsers @user_name NVARCHAR(20), @user_fname NVARCHAR(20), @user_lname NVARCHAR(20),
                                    @user_email NVARCHAR(50), @user_password NVARCHAR(50), @role_id INT
AS
    SET NOCOUNT ON;

BEGIN TRY
    INSERT INTO Users (user_name, user_fname, user_lname, email_address, password, role_id)
    VALUES (@user_name, @user_fname, @user_lname, @user_email, @user_password, @role_id)
END TRY
BEGIN CATCH
    SELECT ERROR_NUMBER()    AS ErrorNumber,
           ERROR_MESSAGE()   AS ErrorMessage,
           ERROR_PROCEDURE() AS ErrorProcedure,
           ERROR_LINE()      AS ErrorLine
END CATCH
GO

