CREATE PROCEDURE st_updateExam @exam_id INT, @exam_name NVARCHAR(50), @exam_final_grade DECIMAL(5, 2), @student_id INT
AS
    SET NOCOUNT ON;

BEGIN TRY
    UPDATE Exam
    SET ex_name        = @exam_name,
        ex_final_grade = @exam_final_grade,
        st_id          = @student_id
    WHERE ex_id = @exam_id;
END TRY
BEGIN CATCH
    SELECT ERROR_NUMBER()    AS ErrorNumber,
           ERROR_MESSAGE()   AS ErrorMessage,
           ERROR_PROCEDURE() AS ErrorProcedure,
           ERROR_LINE()      AS ErrorLine
END CATCH
GO

