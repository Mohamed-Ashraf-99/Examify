CREATE PROCEDURE st_insertIntoStudies @student_id INT, @course_id INT
AS
    SET NOCOUNT ON;
    
BEGIN TRY
    INSERT INTO Studies (st_id, crs_id)
    VALUES (@student_id, @course_id)
END TRY
BEGIN CATCH
    SELECT ERROR_NUMBER()    AS ErrorNumber,
           ERROR_MESSAGE()   AS ErrorMessage,
           ERROR_PROCEDURE() AS ErrorProcedure,
           ERROR_LINE()      AS ErrorLine
END CATCH
GO

