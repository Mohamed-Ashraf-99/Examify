CREATE   PROCEDURE st_getTopicsByCourseID @course_id INT
AS
    SET NOCOUNT ON;
BEGIN TRY
    SELECT T.topic_id   AS [Topic ID],
           T.topic_name AS [Topic Name]
    FROM Course C
        INNER JOIN Topic T
            ON C.topic_id = T.topic_id
    WHERE C.crs_id = @course_id;
END TRY
BEGIN CATCH
    SELECT ERROR_NUMBER()    AS ErrorNumber,
           ERROR_MESSAGE()   AS ErrorMessage,
           ERROR_PROCEDURE() AS ErrorProcedure,
           ERROR_LINE()      AS ErrorLine
END CATCH
GO

