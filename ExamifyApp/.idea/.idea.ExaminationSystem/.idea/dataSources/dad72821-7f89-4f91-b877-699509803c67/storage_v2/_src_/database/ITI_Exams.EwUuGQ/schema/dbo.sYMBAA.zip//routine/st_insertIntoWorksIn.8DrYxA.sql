CREATE PROCEDURE st_insertIntoWorksIn @instructor_id INT, @department_id INT
AS
    SET NOCOUNT ON;
    
BEGIN TRY
    INSERT INTO Works_in(ins_id, dept_id)
    VALUES (@instructor_id, @department_id)
END TRY
BEGIN CATCH
    SELECT ERROR_NUMBER()    AS ErrorNumber,
           ERROR_MESSAGE()   AS ErrorMessage,
           ERROR_PROCEDURE() AS ErrorProcedure,
           ERROR_LINE()      AS ErrorLine
END CATCH
GO

