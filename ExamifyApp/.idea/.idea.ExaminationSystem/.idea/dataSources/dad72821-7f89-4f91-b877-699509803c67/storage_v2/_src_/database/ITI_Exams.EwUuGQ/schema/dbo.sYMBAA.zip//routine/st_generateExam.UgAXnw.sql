CREATE   PROCEDURE st_generateExam @course_name NVARCHAR(50), @true_false_questions_count INT,
                                          @other_questions_count INT
AS
    SET NOCOUNT ON;

BEGIN TRY
    BEGIN TRANSACTION
        DECLARE @tf_table_count INT, @other_table_count INT, @exam_id INT, @course_id INT, @question_id INT, @count INT;

        SELECT @course_id = crs_id FROM Course WHERE crs_name = @course_name;

        EXECUTE st_insertIntoExam @course_name, NULL, NULL, @exam_id OUT;

        DECLARE @summary_true_false TABLE
                                    (
                                        Row#          INT,
                                        qs_id         INT,
                                        qs_title      NVARCHAR(100),
                                        qs_type       NVARCHAR(20),
                                        qs_difficulty NVARCHAR(20),
                                        qs_grade      DECIMAL(4, 2),
                                        model_answer  INT,
                                        crs_id        INT
                                    )
        DECLARE @summary_other TABLE
                               (
                                   Row#          INT,
                                   qs_id         INT,
                                   qs_title      NVARCHAR(100),
                                   qs_type       NVARCHAR(20),
                                   qs_difficulty NVARCHAR(20),
                                   qs_grade      DECIMAL(4, 2),
                                   model_answer  INT,
                                   crs_id        INT
                               )
        DECLARE @summary_final TABLE
                               (
                                   qs_id         INT,
                                   qs_title      NVARCHAR(100),
                                   qs_type       NVARCHAR(20),
                                   qs_difficulty NVARCHAR(20),
                                   qs_grade      DECIMAL(4, 2),
                                   model_answer  INT,
                                   crs_id        INT
                               )

        INSERT INTO @summary_true_false
        SELECT ROW_NUMBER() OVER (ORDER BY qs_id) AS "Row#",
               q.*
        FROM Question q
            INNER JOIN Course c
                ON q.crs_id = c.crs_id
        WHERE c.crs_name = @course_name
          AND q.qs_type = 'T/F';

        SELECT @tf_table_count = MAX(Row#) FROM @summary_true_false;
        SET @count = 1;

        WHILE @count <= @true_false_questions_count
            BEGIN
                SELECT @question_id = qs_id
                FROM @summary_true_false
                WHERE Row# = FLOOR(RAND() * (@tf_table_count - 1 + 1)) + 1;

                IF @question_id NOT IN (SELECT qs_id FROM Includes WHERE ex_id = @exam_id)
                    BEGIN
                        EXECUTE st_insertIntoIncludes @exam_id, @question_id, NULL;

                        INSERT INTO @summary_final
                        SELECT *
                        FROM Question
                        WHERE qs_id = @question_id;

                        SET @count += 1;
                    END
            END

        INSERT INTO @summary_other
        SELECT ROW_NUMBER() OVER (ORDER BY qs_id) AS "Row#",
               q.*
        FROM Question q
            INNER JOIN Course c
                ON q.crs_id = c.crs_id
        WHERE c.crs_name = @course_name
          AND q.qs_type = 'other';

        SELECT @other_table_count = MAX(Row#) FROM @summary_other;
        SET @count = 1;

        WHILE @count <= @other_questions_count
            BEGIN
                SELECT @question_id = qs_id
                FROM @summary_other
                WHERE Row# = FLOOR(RAND() * (@other_table_count - 1 + 1)) + 1;

                IF @question_id NOT IN (SELECT qs_id FROM Includes WHERE ex_id = @exam_id)
                    BEGIN
                        EXECUTE st_insertIntoIncludes @exam_id, @question_id, NULL;

                        INSERT INTO @summary_final
                        SELECT *
                        FROM Question
                        WHERE qs_id = @question_id;

                        SET @count += 1;
                    END
            END

        SELECT * FROM @summary_final;
    COMMIT TRANSACTION

END TRY
BEGIN CATCH
    SELECT ERROR_NUMBER()    AS ErrorNumber,
           ERROR_MESSAGE()   AS ErrorMessage,
           ERROR_PROCEDURE() AS ErrorProcedure,
           ERROR_LINE()      AS ErrorLine
    ROLLBACK TRANSACTION
END CATCH
GO

