CREATE PROCEDURE st_deleteFromStudent @student_id INT
AS
    SET NOCOUNT ON;

BEGIN TRY
    BEGIN TRANSACTION
        DELETE
        FROM Student
        WHERE st_id = @student_id;
        
        EXECUTE st_deleteFromUsers @student_id;
    COMMIT TRANSACTION
    
END TRY
BEGIN CATCH
    SELECT ERROR_NUMBER()    AS ErrorNumber,
           ERROR_MESSAGE()   AS ErrorMessage,
           ERROR_PROCEDURE() AS ErrorProcedure,
           ERROR_LINE()      AS ErrorLine
END CATCH
GO

