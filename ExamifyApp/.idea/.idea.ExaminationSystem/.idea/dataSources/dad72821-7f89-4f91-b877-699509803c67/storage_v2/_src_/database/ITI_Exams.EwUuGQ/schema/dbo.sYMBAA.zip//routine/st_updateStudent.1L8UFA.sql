CREATE PROCEDURE st_updateStudent @student_id INT, @student_address NVARCHAR(50), @department_id INT,
                                  @student_img nvarchar(100)
AS
    SET NOCOUNT ON;

BEGIN TRY
    UPDATE Student
    SET st_address = @student_address,
        dept_id    = @department_id,
        st_img     = @student_img
    WHERE st_id = @student_id

END TRY
BEGIN CATCH
    SELECT ERROR_NUMBER()    AS ErrorNumber,
           ERROR_MESSAGE()   AS ErrorMessage,
           ERROR_PROCEDURE() AS ErrorProcedure,
           ERROR_LINE()      AS ErrorLine
END CATCH
GO

