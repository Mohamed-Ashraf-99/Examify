CREATE PROCEDURE st_insertIntoInstructor @instructor_id INT, @instructor_degree NVARCHAR(20), @instructor_salary MONEY
AS
    SET NOCOUNT ON;

BEGIN TRY
    INSERT INTO Instructor (ins_id, ins_degree, ins_salary)
    VALUES (@instructor_id, @instructor_degree, @instructor_salary)
END TRY
BEGIN CATCH
    SELECT ERROR_NUMBER()    AS ErrorNumber,
           ERROR_MESSAGE()   AS ErrorMessage,
           ERROR_PROCEDURE() AS ErrorProcedure,
           ERROR_LINE()      AS ErrorLine
END CATCH
GO

