CREATE PROCEDURE st_insertIntoIncludes @exam_id INT, @question_id INT, @student_answer INT
AS
    SET NOCOUNT ON;
    
BEGIN TRY
    INSERT INTO Includes (ex_id, qs_id, st_answer)
    VALUES (@exam_id, @question_id, @student_answer)
END TRY
BEGIN CATCH
    SELECT ERROR_NUMBER()    AS ErrorNumber,
           ERROR_MESSAGE()   AS ErrorMessage,
           ERROR_PROCEDURE() AS ErrorProcedure,
           ERROR_LINE()      AS ErrorLine
END CATCH
GO

