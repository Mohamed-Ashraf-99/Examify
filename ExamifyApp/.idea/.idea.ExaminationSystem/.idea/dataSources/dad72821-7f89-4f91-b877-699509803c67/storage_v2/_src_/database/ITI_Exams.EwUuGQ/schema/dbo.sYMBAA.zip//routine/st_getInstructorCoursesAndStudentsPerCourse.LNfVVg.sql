CREATE   PROCEDURE st_getInstructorCoursesAndStudentsPerCourse @instructor_id INT
AS
    SET NOCOUNT ON;
BEGIN TRY
    SELECT C.crs_name      AS [Course Name],
           COUNT(ST.st_id) AS [Number of Student]
    FROM Teaches T
        INNER JOIN Instructor I
            ON T.ins_id = I.ins_id
        INNER JOIN Course C
            ON C.crs_id = T.crs_id
        INNER JOIN Studies S
            ON S.crs_id = C.crs_id
        INNER JOIN Student ST
            ON ST.st_id = S.st_id
    WHERE I.ins_id = @instructor_id
    GROUP BY C.crs_name;
END TRY
BEGIN CATCH
    SELECT ERROR_NUMBER()    AS ErrorNumber,
           ERROR_MESSAGE()   AS ErrorMessage,
           ERROR_PROCEDURE() AS ErrorProcedure,
           ERROR_LINE()      AS ErrorLine
END CATCH
GO

