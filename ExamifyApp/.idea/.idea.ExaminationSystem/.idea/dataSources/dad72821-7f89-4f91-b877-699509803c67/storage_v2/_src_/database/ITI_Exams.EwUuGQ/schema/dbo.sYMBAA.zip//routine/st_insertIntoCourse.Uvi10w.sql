-- Stored Procedures for The Contains Table
-- INSERT STATEMENT
CREATE PROCEDURE st_insertIntoCourse @course_name NVARCHAR(50), @course_duration INT
AS
    SET NOCOUNT ON;

BEGIN TRY
    INSERT INTO Course (crs_name, crs_duration)
    VALUES (@course_name, @course_duration)
END TRY
BEGIN CATCH
    SELECT ERROR_NUMBER()    AS ErrorNumber,
           ERROR_MESSAGE()   AS ErrorMessage,
           ERROR_PROCEDURE() AS ErrorProcedure,
           ERROR_LINE()      AS ErrorLine
END CATCH
GO

