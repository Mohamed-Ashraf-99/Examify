CREATE PROCEDURE st_deleteFromInstructor @instructor_id INT
AS
    SET NOCOUNT ON;

BEGIN TRY
    BEGIN TRANSACTION
        IF (@instructor_id IN (SELECT dept_mgr_id FROM Department))
            BEGIN
                DECLARE @department_id INT;
                
                SELECT @department_id = dept_id
                FROM Department d
                    INNER JOIN Instructor i
                        ON i.ins_id = d.dept_mgr_id
                WHERE i.ins_id = @instructor_id;

                UPDATE Department
                SET dept_mgr_id   = NULL,
                    mgr_hire_date = NULL
                WHERE dept_id = @department_id;
            END

        DELETE
        FROM Instructor
        WHERE ins_id = @instructor_id;
        
        EXECUTE st_deleteFromUsers @instructor_id;
    COMMIT TRANSACTION

END TRY
BEGIN CATCH
    SELECT ERROR_NUMBER()    AS ErrorNumber,
           ERROR_MESSAGE()   AS ErrorMessage,
           ERROR_PROCEDURE() AS ErrorProcedure,
           ERROR_LINE()      AS ErrorLine
END CATCH
GO

