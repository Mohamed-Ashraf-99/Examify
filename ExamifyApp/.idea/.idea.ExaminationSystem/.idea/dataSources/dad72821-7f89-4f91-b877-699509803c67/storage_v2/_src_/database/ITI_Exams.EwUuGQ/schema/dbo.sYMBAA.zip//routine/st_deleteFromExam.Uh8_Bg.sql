CREATE   PROCEDURE st_deleteFromExam @exam_id int
AS
    SET NOCOUNT ON;
    
BEGIN TRY
    DELETE FROM Exam
    WHERE ex_id = @exam_id;
END TRY
BEGIN CATCH
    SELECT ERROR_NUMBER()    AS ErrorNumber,
           ERROR_MESSAGE()   AS ErrorMessage,
           ERROR_PROCEDURE() AS ErrorProcedure,
           ERROR_LINE()      AS ErrorLine
END CATCH
GO

